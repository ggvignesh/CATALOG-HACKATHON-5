class Charger:
    def __init__(self, charger_id, charger_type, availability):
        self.charger_id = charger_id
        self.charger_type = charger_type
        self.availability = availability  # Dictionary with time slots and their availability status

class ChargingStation:
    def __init__(self, station_id, location, chargers):
        self.station_id = station_id
        self.location = location
        self.chargers = chargers  # List of Charger objects

class User:
    def __init__(self, user_id, name):
        self.user_id = user_id
        self.name = name

def find_charging_stations(stations, location=None, charger_type=None):
    filtered_stations = []
    for station in stations:
        if location and station.location != location:
            continue
        for charger in station.chargers:
            if charger_type and charger.charger_type != charger_type:
                continue
            filtered_stations.append(station)
            break
    return filtered_stations

def book_charging_slot(user, station, charger_id, time_slot):
    for charger in station.chargers:
        if charger.charger_id == charger_id:
            if charger.availability.get(time_slot) == 'available':
                charger.availability[time_slot] = user.user_id
                print(f"Slot booked for {user.name} at {time_slot}")
                return True
            else:
                print("Slot not available")
                return False
    print("Charger not found")
    return False

# Example Usage

# Define some chargers with time slots
charger1 = Charger(charger_id=1, charger_type='Type 2', availability={
    '10:00-11:00': 'available', 
    '11:00-12:00': 'available'
})
charger2 = Charger(charger_id=2, charger_type='Fast Charger', availability={
    '10:00-11:00': 'available', 
    '11:00-12:00': 'booked'
})

# Define a station
station1 = ChargingStation(station_id=101, location='Downtown', chargers=[charger1, charger2])

# Define a user
user1 = User(user_id=201, name='John Doe')

# Find stations in 'Downtown' with 'Type 2' chargers
stations = find_charging_stations([station1], location='Downtown', charger_type='Type 2')
print(f"Found {len(stations)} station(s)")

# Book a slot
book_charging_slot(user1, station1, charger_id=1, time_slot='10:00-11:00')
